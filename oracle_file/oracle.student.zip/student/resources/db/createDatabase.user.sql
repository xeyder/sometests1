create user COHERENCE identified by COHERENCE; 
grant dba to COHERENCE;
grant connect to COHERENCE; 
grant resource to COHERENCE; 
grant all privileges to COHERENCE; 
exit;
