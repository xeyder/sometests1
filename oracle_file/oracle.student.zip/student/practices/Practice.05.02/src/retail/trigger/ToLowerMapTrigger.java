package retail.trigger;


import com.oracle.education.retail.Item;
import com.tangosol.util.MapTrigger;

// 
// TODO: Must implement the MapTrigger interface 
//
public class ToLowerMapTrigger {

	private static final long serialVersionUID = 1L;



	public boolean equals(Object o) {
		return o != null && o.getClass() == this.getClass();
	}

	public int hashCode() {
		return getClass().getName().hashCode();
	}

	//
	// TODO: Complete the implementation of the process method 
	//

}
