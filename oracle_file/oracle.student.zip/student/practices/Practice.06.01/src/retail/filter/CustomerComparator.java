package retail.filter;

import java.util.Comparator;

import com.oracle.education.retail.Customer;

//
// TODO: Complete the comparator by implementing the Comparator interface
//       Cast the two objects to Customer and then compare the names
//       See the Practice.06.01\ resource directory for a complete implementation of the compare method
public class CustomerComparator {

	public int compare(Object first, Object second) {
		return 0;
	}

}
