package com.oracle.education.coherence.examples;

public interface Entity<T> {

	T getId();
}
