package com.oracle.education.coherence.examples.domain;

public interface Entity<T> {

	T getId();
}
