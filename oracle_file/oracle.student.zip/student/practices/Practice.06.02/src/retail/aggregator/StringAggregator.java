package retail.aggregator;

import com.tangosol.util.ValueExtractor;
import com.tangosol.util.aggregator.AbstractAggregator;

//
// TODO: Must extend AbstractAggregator
//
public class StringAggregator {


	transient StringBuffer results;
	
	// required for serialization
	public StringAggregator() { super(); }
	
	//
	//TODO: implement the ValueExtractor constructor
	//
	

	//
	//TODO: implement the init method
	//
	
	
	//
	// TODO: Implement the process method
	//
	

	//
	// TODO: Complete the finalizeResults method
	//
	



}
