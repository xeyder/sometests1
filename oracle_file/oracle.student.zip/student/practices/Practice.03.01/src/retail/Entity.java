package retail;

public interface Entity<T> {

	public T getId();
	public String toString();
}
