
public class CacheTester {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO: Place code to get access to the Invocation Service

		System.out.println("Invoking the service synchronously");
		// TODO: Place the code that synchronously executes the FreeMemoryAgent class
		// and prints out the results

		System.out.println("\nInvoking the service asynchronously");
		// TODO: Place the code here that asynchronously executes the FreeMemoryAgent class
		// which uses the MyInvocationObserver class to print out results
		System.out.println("Asynchronous execution finished\n");
	}
}
