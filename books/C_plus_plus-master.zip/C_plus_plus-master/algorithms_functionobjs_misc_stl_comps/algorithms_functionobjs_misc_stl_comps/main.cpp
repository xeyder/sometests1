//
//  main.cpp
//  algorithms_functionobjs_misc_stl_comps
//
//  Created by Sudheendra Ayalasomayajula on 6/25/13.
//  Copyright (c) 2013 Sudheendra Ayalasomayajula. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[])
{

    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}

